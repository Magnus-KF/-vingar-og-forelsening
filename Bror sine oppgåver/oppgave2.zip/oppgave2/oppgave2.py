
# Lag ein klasse som heiter Bil
# Bil har tre variablar: merke, modell og årsmodell
# Alle tre variablane blir satt når man lager bilen for eksempel sånn her:
minFord = Bil("Ford", "Fiesta", "1987")

# I bilklassen er det også ein funksjon printInfo()
# Den printen merket, modellen og årsmodellen til bilen, for eksempel sånn:
"Bilen er en Ford Fiesta og ble laget i 1987"
