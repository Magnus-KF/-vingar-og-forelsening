
class Bil:
    def __init__(self, merke, modell, årsmodell):
        self.merke = merke
        self.modell = modell
        self.årsmodell = årsmodell
    
    def printInfo(self):
        print("Bilen er en", self.merke, self.modell, "og ble laget i", self.årsmodell)

minFord = Bil("Ford", "Fiesta", "1987")
minFord.printInfo()